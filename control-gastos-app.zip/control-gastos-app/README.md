# Control de Gastos

App de control de presupuesto mensual con Google Sheets como base de datos.

## Deploy en Vercel (5 minutos)

1. Sube esta carpeta a un repo en GitHub
2. Entra a vercel.com → "Add New Project" → importa el repo
3. Vercel detecta React automáticamente → click "Deploy"
4. En 2 minutos tienes tu URL

## Datos

Todos los datos se guardan en Google Sheets:
- Hoja ID: 1-CJycsVFxdMcaSXwv7uVjv_dNpSXG22RVX1H6acRiDI
- Pestañas: Categorias, Presupuestos, Gastos
